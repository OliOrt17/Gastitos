<?php
require_once 'Medoo.php';

use Medoo\Medoo;

$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'softengi_datac',
    'server' => 'softenginesolutions.com.mx',
    'username' => 'softengi_root',
    'password' => 'Z9G*tQI~[=-h'
]);

?>
